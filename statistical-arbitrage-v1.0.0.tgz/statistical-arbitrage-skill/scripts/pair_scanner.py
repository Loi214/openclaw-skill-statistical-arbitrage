#!/usr/bin/env python3
"""
股票對掃描器 - 自動找出最佳配對
支持多市場、雙語輸出
"""
import pandas as pd
import numpy as np
import yfinance as yf
import statsmodels.api as sm
from statsmodels.tsa.stattools import coint
from datetime import datetime
import warnings
import json
import argparse
from pathlib import Path
from itertools import combinations
warnings.filterwarnings('ignore')

# 預設股票池
STOCK_POOLS = {
    # 港股
    "hk_bluechip": {
        "name": "港股藍籌",
        "name_en": "HK Blue Chip",
        "stocks": [
            "0001.HK",  # 匯豐控股
            "0005.HK",  # 滙豐控股
            "0011.HK",  # 恒生銀行
            "0012.HK",  # 恒生銀行
            "0016.HK",  # 創興銀行
            "0017.HK",  # 新鴻基地產
            "0019.HK",  # 太古股份
            "0066.HK",  # 港鐵公司
            "0101.HK",  # 中國過海隧道
            "0113.HK",  # 長實地產
        ]
    },
    "hk_bank": {
        "name": "港股銀行",
        "name_en": "HK Banks",
        "stocks": [
            "0939.HK",  # 建設銀行
            "1398.HK",  # 工商銀行
            "0001.HK",  # 匯豐控股
            "0011.HK",  # 恒生銀行
            "0388.HK",  # 香港交易所
            "0027.HK",  # 銀河娛樂
            "0005.HK",  # 滙豐控股
            "2388.HK",  # 中國平安
            "2318.HK",  # 中國平安
            "1288.HK",  # 農業銀行
        ]
    },
    "hk_tech": {
        "name": "港股科技",
        "name_en": "HK Tech",
        "stocks": [
            "0700.HK",  # 騰訊
            "9988.HK",  # 阿里巴巴
            "3690.HK",  # 美團
            "1024.HK",  # 快手
            "9618.HK",  # 京東
            "9888.HK",  # 百度
            "1810.HK",  # 小米
            "6630.HK",  # 攜程
            "9999.HK",  # 網易
            "1900.HK",  # 中國鐵塔
        ]
    },
    # 美股
    "us_tech": {
        "name": "美股科技",
        "name_en": "US Tech",
        "stocks": [
            "AAPL",     # Apple
            "MSFT",     # Microsoft
            "GOOGL",    # Alphabet
            "META",     # Meta
            "NVDA",     # NVIDIA
            "AMD",      # AMD
            "AMZN",     # Amazon
            "NFLX",     # Netflix
            # SPGI, MCO moved to us_finance
        ]
    },
    "us_faang": {
        "name": "美股FAANG",
        "name_en": "US FAANG",
        "stocks": [
            "META",     # Meta
            "AAPL",     # Apple
            "AMZN",     # Amazon
            "NFLX",     # Netflix
            "GOOGL",    # Alphabet
            "MSFT",     # Microsoft
        ]
    },
    "us_finance": {
        "name": "美股金融",
        "name_en": "US Finance",
        "stocks": [
            "JPM",      # JP Morgan
            "BAC",      # Bank of America
            "WFC",      # Wells Fargo
            "GS",       # Goldman Sachs
            "MS",       # Morgan Stanley
            "SPGI",     # S&P Global
            "MCO",      # Moody's
            "AXP",      # American Express
            "BLK",      # BlackRock
            "C",        # Citi
        ]
    },
    # A股
    "cn_bank": {
        "name": "A股銀行",
        "name_en": "China Banks",
        "stocks": [
            "601398.SH",  # 工商銀行
            "601939.SH",  # 建設銀行
            "601988.SH",  # 中國銀行
            "601288.SH",  # 農業銀行
            "600036.SH",  # 招商銀行
            "601166.SH",  # 興業銀行
            "600015.SH",  # 華夏銀行
            "600016.SH",  # 民生銀行
            "600015.SH",  # 平安銀行
            "601328.SH",  # 交通銀行
        ]
    },
    "cn_tech": {
        "name": "A股科技",
        "name_en": "China Tech",
        "stocks": [
            "600519.SH",  # 貴州茅臺
            "000333.SZ",  # 美的集團
            "000651.SZ",  # 格力電器
            "002475.SZ",  # 立訊精密
            "300750.SZ",  # 寧德時代
            "002594.SZ",  # 比亞迪
            "600036.SH",  # 招商銀行
            "601012.SH",  # 隆基股份
            "300059.SZ",  # 東方財富
            "688981.SH",  # 中芯國際
        ]
    },
}


def download_stock_data(tickers, start_date, end_date, lang="en"):
    """Download stock data"""
    data = {}
    failed = []
    is_cn = (lang == "zh")
    
    if is_cn:
        print(f"下载数据中...")
    else:
        print(f"Downloading data...")
    
    for ticker in tickers:
        try:
            df = yf.download(ticker, start=start_date, end=end_date, progress=False)
            if df.empty:
                failed.append(ticker)
                continue
            
            if isinstance(df.columns, pd.MultiIndex):
                df = df.xs(ticker, axis=1, level='Ticker').copy()
            
            # Filter zero volume
            df = df[df['Volume'] > 0]
            
            if len(df) > 50:
                data[ticker] = df['Close']
                if is_cn:
                    print(f"  ✓ {ticker}: {len(df)} 天")
                else:
                    print(f"  OK: {ticker} - {len(df)} days")
            else:
                failed.append(ticker)
        except Exception as e:
            failed.append(ticker)
            if is_cn:
                print(f"  ✗ {ticker}")
            else:
                print(f"  FAIL: {ticker}")
    
    if is_cn:
        print(f"  成功: {len(data)}, 失败: {len(failed)}")
    else:
        print(f"  Success: {len(data)}, Failed: {len(failed)}")
    return pd.DataFrame(data)


def test_cointegration(series1, series2):
    """測試協整關係"""
    try:
        # 對齊數據
        combined = pd.DataFrame({'s1': series1, 's2': series2}).dropna()
        if len(combined) < 50:
            return None
        
        # 協整檢驗
        score, p_value, _ = coint(combined['s1'], combined['s2'], autolag='AIC')
        
        if p_value < 0.05:
            # 計算對沖比率和R²
            X = sm.add_constant(combined['s2'])
            model = sm.OLS(combined['s1'], X).fit()
            beta = model.params.iloc[1]
            r_squared = model.rsquared
            
            return {
                'p_value': p_value,
                'beta': beta,
                'r_squared': r_squared,
                'data_points': len(combined)
            }
    except:
        pass
    return None


def scan_pairs(stocks, start_date, end_date, lang="en"):
    """扫描所有股票对"""
    is_cn = (lang == "zh")
    
    # 下载数据
    price_data = download_stock_data(stocks, start_date, end_date, lang)
    
    if price_data.empty:
        if is_cn:
            print("❌ 无法下载数据")
        else:
            print("FAIL: Cannot download data")
        return []
    
    results = []
    total = len(list(combinations(price_data.columns, 2)))
    if is_cn:
        print(f"\n测试 {total} 种配对组合...")
    else:
        print(f"\nTesting {total} pair combinations...")
    
    for i, (s1, s2) in enumerate(combinations(price_data.columns, 2)):
        if (i + 1) % 10 == 0:
            if is_cn:
                print(f"  进度: {i+1}/{total}")
            else:
                print(f"  Progress: {i+1}/{total}")
        
        result = test_cointegration(price_data[s1], price_data[s2])
        
        if result:
            # 添加評分
            score = calculate_score(result['p_value'], result['r_squared'])
            results.append({
                'stock1': s1,
                'stock2': s2,
                'p_value': result['p_value'],
                'beta': result['beta'],
                'r_squared': result['r_squared'],
                'data_points': result['data_points'],
                'score': score
            })
    
    # 按p值排序
    results.sort(key=lambda x: x['p_value'])
    return results


def calculate_score(p_value, r_squared):
    """計算評分"""
    # p值越低越好，R²越高越好
    p_score = max(0, (0.05 - p_value) / 0.05) * 50
    r_score = r_squared * 50
    return min(100, p_score + r_score)


def get_stock_name(ticker):
    """獲取股票名稱"""
    names = {
        "AAPL": "Apple Inc.",
        "MSFT": "Microsoft",
        "GOOGL": "Alphabet",
        "META": "Meta Platforms",
        "NVDA": "NVIDIA",
        "AMD": "AMD",
        "AMZN": "Amazon",
        "NFLX": "Netflix",
        "SPGI": "S&P Global",
        "MCO": "Moody's",
        "JPM": "JPMorgan Chase",
        "BAC": "Bank of America",
        "WFC": "Wells Fargo",
        "GS": "Goldman Sachs",
        "MS": "Morgan Stanley",
        "AXP": "American Express",
        "BLK": "BlackRock",
        "C": "Citigroup",
        "1398.HK": "ICBC (工商銀行)",
        "0939.HK": "CCB (建設銀行)",
        "0001.HK": "HSBC (匯豐)",
        "0011.HK": "Hang Seng Bank",
        "0700.HK": "Tencent (騰訊)",
        "9988.HK": "Alibaba (阿里巴巴)",
        "3690.HK": "Meituan (美團)",
        "601398.SH": "ICBC (工商銀行)",
        "601939.SH": "CCB (建設銀行)",
        "601988.SH": "BOC (中國銀行)",
    }
    return names.get(ticker, ticker)


def is_chinese(text):
    """检测是否包含中文"""
    for char in text:
        if '\u4e00' <= char <= '\u9fff':
            return True
    return False

def print_results(results, pool_name, pool_name_en, top_n=10, lang=None):
    """Print results - bilingual based on input"""
    # 自动检测语言
    if lang is None:
        lang = "en"  # 默认英文
    
    is_cn = (lang == "zh")
    
    if is_cn:
        # 中文输出
        print(f"\n{'='*70}")
        print(f"📊 {pool_name} 股票对扫描结果")
        print(f"{'='*70}")
        
        if not results:
            print("❌ 未找到显著配对")
            return
        
        print(f"\n🏆 Top {min(top_n, len(results))} 最佳配对")
        print(f"{'─'*70}")
        print(f"{'排名':<5} {'股票对':<20} {'p值':<10} {'β':<8} {'R²':<8} {'评分':<8}")
        print(f"{'─'*70}")
        
        for i, r in enumerate(results[:top_n], 1):
            stars = "⭐" * (3 if r['score'] > 70 else 2 if r['score'] > 50 else 1)
            print(f"{i:<5} {r['stock1']}-{r['stock2']:<14} {r['p_value']:<10.6f} {r['beta']:<8.3f} {r['r_squared']:<8.3f} {r['score']:.1f} {stars}")
        
        print(f"{'─'*70}")
        print(f"\n💡 说明:")
        print(f"  • p值 < 0.05: 显著协整关系")
        print(f"  • β: 对冲比率")
        print(f"  • R²: 回归拟合度（越高越好）")
        print(f"  • 评分 > 70: ⭐⭐⭐ 强推")
        print(f"  • 评分 50-70: ⭐⭐ 建议")
        print(f"  • 评分 < 50: ⭐ 谨慎考虑")
        
        if len(results) >= 3:
            print(f"\n📈 Top 3 详细分析:")
            for i, r in enumerate(results[:3], 1):
                name1 = get_stock_name(r['stock1'])
                name2 = get_stock_name(r['stock2'])
                print(f"\n  #{i} {r['stock1']} ({name1}) vs {r['stock2']} ({name2})")
                print(f"      p值: {r['p_value']:.6f} | β: {r['beta']:.4f} | R²: {r['r_squared']:.4f}")
                print(f"      数据点: {r['data_points']} 天")
    else:
        # 英文输出
        print(f"\n{'='*70}")
        print(f"US Tech Stock Pair Scanner")
        print(f"{'='*70}")
        
        if not results:
            print("No significant pairs found")
            return
        
        print(f"\nTop {min(top_n, len(results))} Best Pairs")
        print(f"{'─'*70}")
        print(f"{'Rank':<5} {'Stock Pair':<20} {'p-value':<10} {'Beta':<8} {'R2':<8} {'Score':<8}")
        print(f"{'─'*70}")
        
        for i, r in enumerate(results[:top_n], 1):
            stars = "*" * (3 if r['score'] > 70 else 2 if r['score'] > 50 else 1)
            print(f"{i:<5} {r['stock1']}-{r['stock2']:<14} {r['p_value']:<10.6f} {r['beta']:<8.3f} {r['r_squared']:<8.3f} {r['score']:.1f} {stars}")
        
        print(f"{'─'*70}")
        print(f"\nNotes:")
        print(f"  - p-value < 0.05: Significant cointegration")
        print(f"  - Beta: Hedging ratio")
        print(f"  - R2: Regression fit (higher is better)")
        print(f"  - Score > 70: Highly recommended ***")
        print(f"  - Score 50-70: Good **")
        print(f"  - Score < 50: Consider carefully *")
        
        if len(results) >= 3:
            print(f"\nTop 3 Detailed Analysis:")
            for i, r in enumerate(results[:3], 1):
                name1 = get_stock_name(r['stock1'])
                name2 = get_stock_name(r['stock2'])
                print(f"\n  #{i} {r['stock1']} ({name1}) vs {r['stock2']} ({name2})")
                print(f"      p-value: {r['p_value']:.6f} | Beta: {r['beta']:.4f} | R2: {r['r_squared']:.4f}")
                print(f"      Data points: {r['data_points']} days")
    print(f"\n{'='*70}")
    print(f"US Tech Stock Pair Scanner")
    print(f"{'='*70}")
    
    if not results:
        print("No significant pairs found")
        return
    
    print(f"\nTop {min(top_n, len(results))} Best Pairs")
    print(f"{'─'*70}")
    print(f"{'Rank':<5} {'Stock Pair':<20} {'p-value':<10} {'Beta':<8} {'R2':<8} {'Score':<8}")
    print(f"{'─'*70}")
    
    for i, r in enumerate(results[:top_n], 1):
        stars = "*" * (3 if r['score'] > 70 else 2 if r['score'] > 50 else 1)
        print(f"{i:<5} {r['stock1']}-{r['stock2']:<14} {r['p_value']:<10.6f} {r['beta']:<8.3f} {r['r_squared']:<8.3f} {r['score']:.1f} {stars}")
    
    print(f"{'─'*70}")
    print(f"\nNotes:")
    print(f"  - p-value < 0.05: Significant cointegration")
    print(f"  - Beta: Hedging ratio")
    print(f"  - R2: Regression fit (higher is better)")
    print(f"  - Score > 70: Highly recommended ***")
    print(f"  - Score 50-70: Good **")
    print(f"  - Score < 50: Consider carefully *")
    
    # Show top 3 details
    if len(results) >= 3:
        print(f"\nTop 3 Detailed Analysis:")
        for i, r in enumerate(results[:3], 1):
            name1 = get_stock_name(r['stock1'])
            name2 = get_stock_name(r['stock2'])
            print(f"\n  #{i} {r['stock1']} ({name1}) vs {r['stock2']} ({name2})")
            print(f"      p-value: {r['p_value']:.6f} | Beta: {r['beta']:.4f} | R2: {r['r_squared']:.4f}")
            print(f"      Data points: {r['data_points']} days")


def main():
    parser = argparse.ArgumentParser(description='Stock Pair Scanner')
    parser.add_argument('--pool', default='us_tech', 
                       help='Stock pool: us_tech, hk_bank, hk_bluechip, cn_bank, cn_tech, us_finance, us_faang')
    parser.add_argument('--start', default='2022-01-01', help='Start date (YYYY-MM-DD)')
    parser.add_argument('--end', default=datetime.now().strftime('%Y-%m-%d'), help='End date (YYYY-MM-DD)')
    parser.add_argument('--top', type=int, default=10, help='Number of results to show')
    parser.add_argument('--lang', default='auto', help='Language: en, zh, or auto')
    parser.add_argument('--custom', help='Custom stock list (comma-separated)')
    
    args = parser.parse_args()
    
    # Determine language
    if args.lang == 'auto':
        # Auto-detect from pool name
        lang = "zh" if "hk" in args.pool or "cn" in args.pool else "en"
    else:
        lang = args.lang
    
    # 確定股票列表
    if args.custom:
        stocks = [s.strip() for s in args.custom.split(',')]
        pool_name = "Custom"
        pool_name_en = "Custom"
    else:
        pool = STOCK_POOLS.get(args.pool)
        if not pool:
            print(f"❌ Invalid pool: {args.pool}")
            print(f"Available pools: {', '.join(STOCK_POOLS.keys())}")
            return
        stocks = pool['stocks']
        pool_name = pool['name']
        pool_name_en = pool['name_en']
    
    is_cn = (lang == "zh")
    
    if is_cn:
        print(f"\n=== 开始扫描 ===")
        print(f"时间范围: {args.start} 至 {args.end}")
        print(f"股票池: {args.pool}")
        print(f"股票数量: {len(stocks)} ({', '.join(stocks)})")
        print(f"测试配对数: {len(list(combinations(stocks, 2)))}")
    else:
        print(f"\n=== Starting scan ===")
        print(f"Period: {args.start} to {args.end}")
        print(f"Stock pool: {args.pool}")
        print(f"Stocks: {len(stocks)} ({', '.join(stocks)})")
        print(f"Total pairs to test: {len(list(combinations(stocks, 2)))}")
    
    results = scan_pairs(stocks, args.start, args.end, lang=lang)
    print_results(results, pool_name, pool_name_en, args.top, lang=lang)
    
    # 保存結果
    if results:
        df = pd.DataFrame(results)
        output_file = f"scan_results_{args.pool}_{datetime.now().strftime('%Y%m%d')}.csv"
        df.to_csv(output_file, index=False)
        print(f"\n✅ Results saved to: {output_file}")


if __name__ == '__main__':
    main()